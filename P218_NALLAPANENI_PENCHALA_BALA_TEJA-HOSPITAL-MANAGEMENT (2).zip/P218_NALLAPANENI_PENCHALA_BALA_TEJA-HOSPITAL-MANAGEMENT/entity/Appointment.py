class Appointment:
    def __init__(self, appointment_id: int, patient_id: int, doctor_id: int, appointment_date: str, description: str):
        self.appointment_id = appointment_id
        self.patient_id = patient_id
        self.doctor_id = doctor_id
        self.appointment_date = appointment_date
        self.description = description

    def get_appointment_id(self):
        return self.appointment_id

    def get_patient_id(self):
        return self.patient_id

    def get_doctor_id(self):
        return self.doctor_id

    def get_appointment_date(self):
        return self.appointment_date

    def get_description(self):
        return self.description

    def set_appointment_id(self, appointment_id: int):
        self.appointment_id = appointment_id

    def set_patient_id(self, patient_id: int):
        self.patient_id = patient_id

    def set_doctor_id(self, doctor_id: int):
        self.doctor_id = doctor_id

    def set_appointment_date(self, appointment_date: str):
        self.appointment_date = appointment_date

    def set_description(self, description: str):
        self.description = description

    def __str__(self):
        return f"Appointment(ID: {self.appointment_id}, Patient ID: {self.patient_id}, Doctor ID: {self.doctor_id}, Date: {self.appointment_date}, Description: {self.description})"
