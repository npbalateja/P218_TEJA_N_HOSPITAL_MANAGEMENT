from dao.IHospitalServiceImpl import HospitalServiceImpl
from entity.Patient import Patient
from entity.Doctor import Doctor
from entity.Appointment import Appointment
from exception.PatientNumberNotFoundException import PatientNumberNotFoundException

def patient_management_menu(service):
    while True:
        print("\n---------- Patient Management----------")
        print("1. Add Patient")
        print("2. Update Patient")
        print("3. Remove Patient")
        print("4. List Patients")
        print("5. Find Patient by ID")
        print("6. Back to Main Menu")

        choice = input("Choose an option: ")
        if choice == '1':
            patient_id = int(input("Enter Patient ID: "))
            first_name = input("Enter First Name: ")
            last_name = input("Enter Last Name: ")
            date_of_birth = input("Enter Date of Birth (YYYY-MM-DD): ")
            gender = input("Enter Gender (M/F): ")
            contact_number = input("Enter Contact Number: ")
            address = input("Enter Address: ")

            try:
                existing_patient = service.get_patient_by_id(patient_id)
                print(f"Patient ID {patient_id} already exists. Please use a different ID.")
                continue
            except PatientNumberNotFoundException:
                pass
            
            gender = gender.lower() if gender in ['M', 'F'] else gender
            
            patient = Patient(patient_id, first_name, last_name, date_of_birth, gender, contact_number, address)
            service.add_patient(patient)
            print(f"Patient {first_name} {last_name} added successfully!")

        elif choice == '2':
            patient_id = int(input("Enter Patient ID to update: "))
            try:
                patient = service.get_patient_by_id(patient_id)
                first_name = input(f"Enter new First Name (current: {patient.get_first_name()}): ") or patient.get_first_name()
                last_name = input(f"Enter new Last Name (current: {patient.get_last_name()}): ") or patient.get_last_name()
                date_of_birth = input(f"Enter new Date of Birth (current: {patient.get_date_of_birth()}): ") or patient.get_date_of_birth()
                gender = input(f"Enter new Gender (current: {patient.get_gender()}): ") or patient.get_gender()
                contact_number = input(f"Enter new Contact Number (current: {patient.get_contact_number()}): ") or patient.get_contact_number()
                address = input(f"Enter new Address (current: {patient.get_address()}): ") or patient.get_address()

                updated_patient = Patient(patient_id, first_name, last_name, date_of_birth, gender, contact_number, address)
                service.update_patient(updated_patient)
                print(f"Patient {patient_id} updated successfully!")

            except PatientNumberNotFoundException as e:
                print(e)

        elif choice == '3':
            patient_id = int(input("Enter Patient ID to remove: "))
            try:
                service.delete_patient(patient_id)
                print(f"Patient with ID {patient_id} removed successfully!")
            except Exception as e:
                print(f"Error: {e}")

        elif choice == '4':
            patients = service.get_all_patients()
            print("\nList of Patients:")
            for patient in patients:
                print(patient)

        elif choice == '5':
            patient_id = int(input("Enter Patient ID to find: "))
            try:
                patient = service.get_patient_by_id(patient_id)
                print("Patient found:", patient)
            except PatientNumberNotFoundException as e:
                print(e)
        elif choice == '6':
            break
        else:
            print("Invalid option. Please try again.")

def doctor_management_menu(service):
    while True:
        print("\n---------- Doctor Management----------")
        print("1. Add Doctor")
        print("2. Update Doctor")
        print("3. Remove Doctor")
        print("4. List Doctors")
        print("5. Find Doctor by ID")
        print("6. Back to Main Menu")
        choice = input("Choose an option: ")

        if choice == '1':
            doctor_id = int(input("Enter Doctor ID: "))
            
            # Check if doctor with this ID already exists
            existing_doctor = service.get_doctor_by_id(doctor_id)
            if existing_doctor:
                print(f"Doctor ID {doctor_id} already exists. Please use a different ID.")
                continue

            # Proceed with adding new doctor
            first_name = input("Enter First Name: ")
            last_name = input("Enter Last Name: ")
            specialization = input("Enter Specialization: ")
            contact_number = input("Enter Contact Number: ")

            # Create Doctor object and add to service
            doctor = Doctor(doctor_id, first_name, last_name, specialization, contact_number)
            service.add_doctor(doctor)
            
            print(f"Doctor {first_name} {last_name} added successfully!")


        elif choice == '2':
            doctor_id = int(input("Enter Doctor ID to update: "))
            try:
                doctor = service.get_doctor_by_id(doctor_id)
                if not doctor:
                    print("No doctor exists with this ID.")
                    continue
                first_name = input(f"Enter new First Name (current: {doctor.get_first_name()}): ") or doctor.get_first_name()
                last_name = input(f"Enter new Last Name (current: {doctor.get_last_name()}): ") or doctor.get_last_name()
                specialization = input(f"Enter new Specialization (current: {doctor.get_specialization()}): ") or doctor.get_specialization()
                contact_number = input(f"Enter new Contact Number (current: {doctor.get_contact_number()}): ") or doctor.get_contact_number()

                updated_doctor = Doctor(doctor_id, first_name, last_name, specialization, contact_number)
                service.update_doctor(updated_doctor)
                print(f"Doctor ID {doctor_id} updated successfully!")
            except Exception as e:
                print(f"Error: {str(e)}")

        elif choice == '3':
            doctor_id = int(input("Enter Doctor ID to remove: "))
            try:
                doctor = service.get_doctor_by_id(doctor_id)
                if not doctor:
                    print(f"No doctor exists with ID {doctor_id}.")
                    continue
                service.delete_doctor(doctor_id)
                print(f"Doctor ID {doctor_id} removed successfully!")
            except Exception as e:
                print(f"Error: {str(e)}")

        elif choice == '4':
            doctors = service.get_all_doctors()
            print("List of Doctors:")
            for doctor in doctors:
                print(f"Doctor(ID: {doctor.get_doctor_id()}, Name: {doctor.get_first_name()} {doctor.get_last_name()}, Specialization: {doctor.get_specialization()}, Contact: {doctor.get_contact_number()})")

        elif choice == '5':
            doctor_id = int(input("Enter Doctor ID to find: "))
            try:
                doctor = service.get_doctor_by_id(doctor_id)
                if doctor:
                    print(f"Doctor(ID: {doctor.get_doctor_id()}, Name: {doctor.get_first_name()} {doctor.get_last_name()}, Specialization: {doctor.get_specialization()}, Contact: {doctor.get_contact_number()})")
                else:
                    print(f"No doctor exists with ID {doctor_id}.")
            except Exception as e:
                print(f"Error: {str(e)}")

        elif choice == '6':
            break
        else:
            print("Invalid option. Please choose again.")


def appointment_management_menu(service):
    while True:
        print("\n----------Appointment Management----------")
        print("1. Schedule Appointment")
        print("2. Update Appointment")
        print("3. Cancel Appointment")
        print("4. List Appointments for Patient")
        print("5. List Appointments for Doctor")
        print("6. Back to Main Menu")
        choice = input("Choose an option: ")
        if choice == '1':  # Schedule Appointment
            appointment_id = int(input("Enter Appointment ID: "))
            existing_appointment = service.get_appointment_by_id(appointment_id)
            if existing_appointment:
                print(f"Appointment ID {appointment_id} already exists. Please use a different ID.")
                continue

            patient_id = int(input("Enter Patient ID: "))
            doctor_id = int(input("Enter Doctor ID: "))
            try:
                patient = service.get_patient_by_id(patient_id)
                doctor = service.get_doctor_by_id(doctor_id)
            except Exception as e:
                print(f"Error: {str(e)}. Please make sure both Patient and Doctor IDs are valid.")
                continue

            appointment_date = input("Enter Appointment Date (YYYY-MM-DD): ")
            description = input("Enter Description: ")

            appointment = Appointment(appointment_id, patient_id, doctor_id, appointment_date, description)
            service.schedule_appointment(appointment)
            print(f"Appointment scheduled successfully for Patient ID {patient_id} with Doctor ID {doctor_id}!")

        elif choice == '2':  # Update Appointment
            appointment_id = int(input("Enter Appointment ID to update: "))
            try:
                appointment = service.get_appointment_by_id(appointment_id)
                if not appointment:
                    print(f"No appointment found with ID {appointment_id}.")
                    continue
                patient_id = input(f"Enter new Patient ID (current: {appointment.get_patient_id()}): ")
                doctor_id = input(f"Enter new Doctor ID (current: {appointment.get_doctor_id()}): ")
                appointment_date = input(f"Enter new Appointment Date (current: {appointment.get_appointment_date()}): ")
                description = input(f"Enter new Description (current: {appointment.get_description()}): ")
                # If fields are left blank, retain old values
                patient_id = int(patient_id) if patient_id else appointment.get_patient_id()
                doctor_id = int(doctor_id) if doctor_id else appointment.get_doctor_id()
                appointment_date = appointment_date or appointment.get_appointment_date()
                description = description or appointment.get_description()

                updated_appointment = Appointment(appointment_id, patient_id, doctor_id, appointment_date, description)
                service.update_appointment(updated_appointment)
                print(f"Appointment ID {appointment_id} updated successfully!")

            except Exception as e:
                print(f"Error: {str(e)}")

        elif choice == '3':  # Cancel Appointment
            appointment_id = int(input("Enter Appointment ID to cancel: "))
            try:
                service.cancel_appointment(appointment_id)
                print(f"Appointment ID {appointment_id} canceled successfully!")
            except Exception as e:
                print(f"Error: {str(e)}")

        elif choice == '4':  # List Appointments for Patient
            patient_id = int(input("Enter Patient ID to list appointments: "))
            try:
                appointments = service.get_appointments_for_patient(patient_id)
                if appointments:
                    print(f"List of Appointments for Patient ID {patient_id}:")
                    for appointment in appointments:
                        print(f"Appointment(ID: {appointment.get_appointment_id()}, Doctor ID: {appointment.get_doctor_id()}, Date: {appointment.get_appointment_date()}, Description: {appointment.get_description()})")
                else:
                    print(f"No appointments found for Patient ID {patient_id}.")
            except Exception as e:
                print(f"Error: {str(e)}")

        elif choice == '5':  # List Appointments for Doctor
            doctor_id = int(input("Enter Doctor ID to list appointments: "))
            try:
                appointments = service.get_appointments_for_doctor(doctor_id)
                if appointments:
                    print(f"List of Appointments for Doctor ID {doctor_id}:")
                    for appointment in appointments:
                        print(f"Appointment(ID: {appointment.get_appointment_id()}, Patient ID: {appointment.get_patient_id()}, Date: {appointment.get_appointment_date()}, Description: {appointment.get_description()})")
                else:
                    print(f"No appointments found for Doctor ID {doctor_id}.")
            except Exception as e:
                print(f"Error: {str(e)}")
        elif choice == '6':  # Back to Main Menu
            break
        else:
            print("Invalid option. Please choose again.")


def main():
    service = HospitalServiceImpl()
    
    while True:
        print("\n===== Hospital Management System =====")
        print("1. Patient Management")
        print("2. Doctor Management")
        print("3. Appointment Management")
        print("4. Exit")
        choice = input("Choose an option: ")
        if choice == '1':
            patient_management_menu(service)
        elif choice == '2':
            doctor_management_menu(service)
        elif choice == '3':
            appointment_management_menu(service)
        elif choice == '4':
            print("Exiting the system.")
            break
        else:
            print("Invalid option. Please try again.")
if __name__ == "__main__":
    main()
