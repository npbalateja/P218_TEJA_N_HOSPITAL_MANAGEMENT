import pyodbc
from util.DBPropertyUtil import DBPropertyUtil

class DBConnection:
    connection = None

    @staticmethod
    def getConnection():
        if DBConnection.connection is None:
            try:
                # Load the database configuration
                config = DBPropertyUtil.getPropertyString('dbconfig.ini')

                # Build the connection string
                connection_str = (
                    f"DRIVER={{ODBC Driver 17 for SQL Server}};"
                    f"SERVER={config['server']};"
                    f"DATABASE={config['database']};"
                    f"Trusted_Connection=yes;"
                )

                # Establish the database connection
                DBConnection.connection = pyodbc.connect(connection_str)
                print("Database connection established successfully.")

            except pyodbc.Error as e:
                print(f"Error while connecting to the database: {e}")
                raise e
            except Exception as e:
                print(f"General error: {e}")
                raise e

        return DBConnection.connection


