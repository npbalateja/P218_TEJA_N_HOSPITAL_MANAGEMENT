import configparser

class DBPropertyUtil:
    @staticmethod
    def getPropertyString(file_name):
        config = configparser.ConfigParser()
        config.read(file_name)

        if 'database' not in config:
            raise Exception("Missing 'database' section in the configuration file.")

        try:
            server = config['database']['server']
            database = config['database']['dbname']

            return {
                "server": server,
                "database": database
            }
        except KeyError as e:
            raise Exception(f"Missing required configuration key: {e}")

