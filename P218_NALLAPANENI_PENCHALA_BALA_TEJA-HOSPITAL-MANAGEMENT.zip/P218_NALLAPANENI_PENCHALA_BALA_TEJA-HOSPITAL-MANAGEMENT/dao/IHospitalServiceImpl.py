import pyodbc
from dao.IHospitalService import IHospitalService
from entity.Patient import Patient
from entity.Doctor import Doctor
from entity.Appointment import Appointment
from exception.PatientNumberNotFoundException import PatientNumberNotFoundException
from util.DBConnection import DBConnection

class HospitalServiceImpl(IHospitalService):
    def __init__(self):
        self.conn = DBConnection.getConnection()
        self.cursor = self.conn.cursor()

    # Patient Management
    def add_patient(self, patient: Patient):
        query = """INSERT INTO Patient (patient_id, first_name, last_name, date_of_birth, gender, contact_number, address)
                VALUES (?, ?, ?, ?, ?, ?, ?)"""
        values = (patient.get_patient_id(), patient.get_first_name(), patient.get_last_name(), 
                  patient.get_date_of_birth(), patient.get_gender(), patient.get_contact_number(), patient.get_address())
        self.cursor.execute(query, values)
        self.conn.commit()

    def update_patient(self, patient: Patient):
        query = """UPDATE Patient SET first_name = ?, last_name = ?, date_of_birth = ?, gender = ?, 
                    contact_number = ?, address = ? WHERE patient_id = ?"""
        values = (patient.get_first_name(), patient.get_last_name(), patient.get_date_of_birth(), 
                  patient.get_gender(), patient.get_contact_number(), patient.get_address(), patient.get_patient_id())
        self.cursor.execute(query, values)
        self.conn.commit()

   

    def delete_patient(self, patient_id: int):
        query = "DELETE FROM Patient WHERE patient_id = ?"
        self.cursor.execute(query, (patient_id,))
        self.conn.commit()

    def get_patient_by_id(self, patient_id: int):
        query = "SELECT * FROM Patient WHERE patient_id = ?"
        self.cursor.execute(query, (patient_id,))
        patient = self.cursor.fetchone()

        if patient is None:
            raise PatientNumberNotFoundException(f"Patient with ID {patient_id} not found")
        return Patient(*patient)

    def get_all_patients(self):
        query = "SELECT * FROM Patient"
        self.cursor.execute(query)
        patients = self.cursor.fetchall()
        return [Patient(*patient) for patient in patients]

    # Doctor Management
    def add_doctor(self, doctor: Doctor):
        # Check if the doctor already exists
        existing_doctor = self.get_doctor_by_id(doctor.get_doctor_id())
        if existing_doctor is not None:
            raise Exception(f"Doctor ID {doctor.get_doctor_id()} already exists. Please use a different ID.")

        query = """INSERT INTO Doctor (doctor_id, first_name, last_name, specialization, contact_number)
                   VALUES (?, ?, ?, ?, ?)"""
        values = (doctor.get_doctor_id(), doctor.get_first_name(), doctor.get_last_name(), 
                  doctor.get_specialization(), doctor.get_contact_number())
        self.cursor.execute(query, values)
        self.conn.commit()


    def update_doctor(self, doctor: Doctor):
        query = """UPDATE Doctor SET first_name = ?, last_name = ?, specialization = ?, contact_number = ?
                   WHERE doctor_id = ?"""
        values = (doctor.get_first_name(), doctor.get_last_name(), doctor.get_specialization(), 
                  doctor.get_contact_number(), doctor.get_doctor_id())
        self.cursor.execute(query, values)
        self.conn.commit()

    def delete_doctor(self, doctor_id: int):
        query = "DELETE FROM Doctor WHERE doctor_id = ?"
        self.cursor.execute(query, (doctor_id,))
        self.conn.commit()

    def get_doctor_by_id(self, doctor_id: int):
        query = "SELECT * FROM Doctor WHERE doctor_id = ?"
        self.cursor.execute(query, (doctor_id,))
        doctor = self.cursor.fetchone()
        return Doctor(*doctor) if doctor else None 

    def get_all_doctors(self):
        query = "SELECT * FROM Doctor"
        self.cursor.execute(query)
        doctors = self.cursor.fetchall()
        return [Doctor(*doctor) for doctor in doctors] 

    # Appointment Management
    def schedule_appointment(self, appointment: Appointment):
        query = """INSERT INTO Appointment (appointment_id, patient_id, doctor_id, appointment_date, description)
                   VALUES (?, ?, ?, ?, ?)"""
        values = (appointment.get_appointment_id(), appointment.get_patient_id(), appointment.get_doctor_id(), 
                  appointment.get_appointment_date(), appointment.get_description())
        self.cursor.execute(query, values)
        self.conn.commit()

    def update_appointment(self, appointment: Appointment):
        query = """UPDATE Appointment SET patient_id = ?, doctor_id = ?, appointment_date = ?, description = ?
                   WHERE appointment_id = ?"""
        values = (appointment.get_patient_id(), appointment.get_doctor_id(), appointment.get_appointment_date(), 
                  appointment.get_description(), appointment.get_appointment_id())
        self.cursor.execute(query, values)
        self.conn.commit()

    def cancel_appointment(self, appointment_id: int):
        query = "DELETE FROM Appointment WHERE appointment_id = ?"
        self.cursor.execute(query, (appointment_id,))
        self.conn.commit()

    def get_appointments_for_patient(self, patient_id: int):
        query = "SELECT * FROM Appointment WHERE patient_id = ?"
        self.cursor.execute(query, (patient_id,))
        appointments = self.cursor.fetchall()
        return [Appointment(*appointment) for appointment in appointments] 

    def get_appointments_for_doctor(self, doctor_id: int):
        query = "SELECT * FROM Appointment WHERE doctor_id = ?"
        self.cursor.execute(query, (doctor_id,))
        appointments = self.cursor.fetchall()
        return [Appointment(*appointment) for appointment in appointments] 
