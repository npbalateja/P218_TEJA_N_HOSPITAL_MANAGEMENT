from abc import ABC, abstractmethod
from entity.Patient import Patient
from entity.Doctor import Doctor
from entity.Appointment import Appointment

class IHospitalService(ABC):

    # Patient Methods
    @abstractmethod
    def add_patient(self, patient: Patient) -> None:
        pass

    @abstractmethod
    def update_patient(self, patient: Patient) -> None:
        pass

    @abstractmethod
    def delete_patient(self, patient_id: int) -> None:
        pass
    
    @abstractmethod
    def get_patient_by_id(self, patient_id: int) -> Patient:
        pass
    
    @abstractmethod
    def get_all_patients(self) -> list[Patient]:
        pass

    # Doctor Methods
    @abstractmethod
    def add_doctor(self, doctor: Doctor) -> None:
        pass

    @abstractmethod
    def update_doctor(self, doctor: Doctor) -> None:
        pass

    @abstractmethod
    def delete_doctor(self, doctor_id: int) -> None:
        pass
    
    @abstractmethod
    def get_doctor_by_id(self, doctor_id: int) -> Doctor:
        pass

    @abstractmethod
    def get_all_doctors(self) -> list[Doctor]:
        pass

    # Appointment Methods
    @abstractmethod
    def schedule_appointment(self, appointment: Appointment) -> None:
        pass

    @abstractmethod
    def update_appointment(self, appointment: Appointment) -> None:
        pass

    @abstractmethod
    def cancel_appointment(self, appointment_id: int) -> None:
        pass 

    @abstractmethod
    def get_appointments_for_patient(self, patient_id: int) -> list[Appointment]:
        pass

    @abstractmethod
    def get_appointments_for_doctor(self, doctor_id: int) -> list[Appointment]:
        pass

