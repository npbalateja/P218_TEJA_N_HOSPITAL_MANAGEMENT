class Doctor:
    def __init__(self, doctor_id: int, first_name: str, last_name: str, specialization: str, contact_number: str):
        self.doctor_id = doctor_id
        self.first_name = first_name
        self.last_name = last_name
        self.specialization = specialization
        self.contact_number = contact_number

    def get_doctor_id(self):
        return self.doctor_id

    def get_first_name(self):
        return self.first_name

    def get_last_name(self):
        return self.last_name

    def get_specialization(self):
        return self.specialization

    def get_contact_number(self):
        return self.contact_number

    def set_doctor_id(self, doctor_id: int):
        self.doctor_id = doctor_id

    def set_first_name(self, first_name: str):
        self.first_name = first_name

    def set_last_name(self, last_name: str):
        self.last_name = last_name

    def set_specialization(self, specialization: str):
        self.specialization = specialization

    def set_contact_number(self, contact_number: str):
        self.contact_number = contact_number

    def __str__(self):
        return f"Doctor(ID: {self.doctor_id}, Name: {self.first_name} {self.last_name}, Specialization: {self.specialization}, Contact: {self.contact_number})"
