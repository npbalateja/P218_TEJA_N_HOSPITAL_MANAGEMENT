class Patient:
    def __init__(self, patient_id: int, first_name: str, last_name: str, date_of_birth: str, gender: str,
                 contact_number: str, address: str):
        self.patient_id = patient_id
        self.first_name = first_name
        self.last_name = last_name
        self.date_of_birth = date_of_birth
        self.gender = gender
        self.contact_number = contact_number
        self.address = address

    def get_patient_id(self):
        return self.patient_id

    def get_first_name(self):
        return self.first_name

    def get_last_name(self):
        return self.last_name

    def get_date_of_birth(self):
        return self.date_of_birth

    def get_gender(self):
        return self.gender

    def get_contact_number(self):
        return self.contact_number

    def get_address(self):
        return self.address

    def set_patient_id(self, patient_id: int):
        self.patient_id = patient_id

    def set_first_name(self, first_name: str):
        self.first_name = first_name

    def set_last_name(self, last_name: str):
        self.last_name = last_name

    def set_date_of_birth(self, date_of_birth: str):
        self.date_of_birth = date_of_birth

    def set_gender(self, gender: str):
        self.gender = gender

    def set_contact_number(self, contact_number: str):
        self.contact_number = contact_number

    def set_address(self, address: str):
        self.address = address

    def __str__(self):
        return f"Patient(ID: {self.patient_id}, Name: {self.first_name} {self.last_name}, DOB: {self.date_of_birth}, " \
               f"Gender: {self.gender}, Contact: {self.contact_number}, Address: {self.address})"
